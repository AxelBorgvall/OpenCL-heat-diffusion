#ifndef READFILE
#define READFILE
#include "config.h"
#include <stdio.h>

Matrix readfile(FILE * f);

void freemat(Matrix * m);
#endif // !READFILE
#define READFILE
